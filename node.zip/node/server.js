

//Diese Datei server.js in einem Ordner anlegen und danach npm init im Terminal verwenden
//Damit bei einer Änderung an der Datei nicht jedesmal der Server neugestartet werden muss kann nodemon installiert werden
// Für Mongo DB:  npm install mongodb --save
//Damit Frontend Site gerendert werden können benötigen wir EJS Template Engine

//Logge Node startet
console.log('Rest Api startet')


//Hinzufügen der benötigten Libraries - Installation mit npm install express --save
const express = require('express')
const bodyParser = require('body-parser')
const MongoClient = require('mongodb').MongoClient
const app = express()

app.use(bodyParser.urlencoded({ extended: true }))

//Definieren auf welchem Port der Server laufen soll
app.listen(3000, function () {
  console.log('listening on 3000')
})

app.set('view engine', 'ejs')

MongoClient.connect("mongodb+srv://fouryou:Zxef7i3OCcsNSdzx@cluster0.gnssf7q.mongodb.net/?retryWrites=true", { useUnifiedTopology: true })
  .then(client => {
    console.log('Connected to Database')
    //Define Collection
    const db = client.db('testdb')

    app.get('/reader', (req, res) => {
  db.collection('testdbcol')
    .find()
    .toArray()
    .then(results => {
      console.log(results)
    res.render('index.ejs', {namedata: results})
    })
    .catch(error => console.error(error))
  // ...

})

    app.post('/setnames', (req, res) => {
   db.collection('testdbcol')
    .insertOne(req.body)
    .then(result => {
      console.log(result)
    })
    .catch(error => console.error(error))
})


app.get('/delete', (req, res) => {
  db.collection('testdbcol').deleteOne({ name: req.body.todelete })
   res.sendFile(__dirname + '/index.html')
})




  })
  .catch(error => console.error(error))


//Beim Aufruf die Index.html zurückliefern



app.get('/', function (req, res) {
  res.sendFile(__dirname + '/index.html')


/*

//Catch den Form Submit
app.post('/quotes', (req, res) => {
  console.log('Form Post')
  console.log(req.body)
})

*/

//Damit die FormularWerte welche übergeben werden von Express.js gelesen werden können benötigt man Body Parser als Middleware
//npm install body-parser --save




})


/*
 .findOneAndUpdate(
    { name: 'Petzer' },
    {
      $set: {
        name: req.body.name,
        quote: req.body.quote,
      },
    },
    options
  )
  .then(result => {

  })
  .catch(error => console.error(error))


*/